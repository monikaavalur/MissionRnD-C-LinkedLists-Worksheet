/*
OVERVIEW: Given a single linked list, remove every Kth node in the linked list.
E.g.: 1->2->3->4->5 and K 2, output is 1->3->5.

INPUTS: A linked list and Value of K.

OUTPUT: Remove every Kth node in the linked list.

ERROR CASES: Return NULL for error cases.

NOTES:
*/

#include <stdio.h>
#include<malloc.h>

struct node {
	int num;
	struct node *next;
};

struct node * removeEveryKthNode(struct node *head, int K)
{
	if (head == NULL || K <= 1)
		return NULL;

	node *current_node , *previous_node;
	current_node = head;
	int count = 0;
	while (current_node!= NULL)
	{
		count+=1;
		current_node = current_node->next;
	}
	previous_node = head;
	current_node = head->next;

	if (K % 2 == 0)
	{
		while (previous_node != NULL && current_node != NULL)
		{
			previous_node->next = current_node->next;
			free(current_node);
			previous_node = previous_node->next;
			if (previous_node != NULL)
				current_node = previous_node->next;
		}
	}

	else if (K % 2 != 0)
	{
		do
		{
			   previous_node = current_node;
			    current_node = current_node->next;
				previous_node->next = current_node->next;
				free(current_node);
				previous_node = previous_node->next;
				current_node = previous_node->next;
		} while (current_node->next != NULL);
	}

	 if (count==K)
	{
		struct node *temp = head;
		struct node *t;
		if (head->next == NULL)
		{
			free(head);
			head = NULL;
		}
		else
		{
			while (temp->next != NULL)
			{
				t = temp;
				temp = temp->next;
			}
			free(t->next);
			t->next = NULL;
		}
	}
	else if (K > count)
	{
		return head;
	}
	return head;
}


